-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bda_db
-- ------------------------------------------------------
-- Server version	5.7.36-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wilaya`
--

DROP TABLE IF EXISTS `wilaya`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wilaya` (
  `Code` smallint(6) NOT NULL,
  `Designation` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Code`),
  UNIQUE KEY `Designation` (`Designation`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wilaya`
--

LOCK TABLES `wilaya` WRITE;
/*!40000 ALTER TABLE `wilaya` DISABLE KEYS */;
INSERT INTO `wilaya` VALUES (1,'Adrar'),(44,'Ain Defla'),(46,'Ain Témouchent'),(16,'Alger'),(23,'Annaba'),(5,'Batna'),(8,'Bechar'),(6,'Bejaïa'),(7,'Biskra'),(9,'Blida'),(34,'Bordj Bou Arreridj'),(10,'Bouira'),(35,'Boumerdès'),(2,'Chlef'),(25,'Constantine'),(17,'Djelfa'),(32,'El Bayadh'),(39,'El Oued'),(47,'Ghardaia'),(24,'Guelma'),(33,'Illizi'),(18,'Jijel'),(40,'Khenchela'),(3,'Laghouat'),(28,'M\'Sila'),(29,'Mascara'),(26,'Medea'),(43,'Mila'),(27,'Mostaganem'),(45,'Naama'),(31,'Oran'),(30,'Ouargla'),(4,'Oum El Bouaghi'),(48,'Relizane'),(20,'Saida'),(19,'Setif'),(22,'Sidi Bel Abbes'),(21,'Skikda'),(41,'Souk Ahras'),(11,'Tamanrasset'),(36,'Tarf'),(12,'Tebessa'),(14,'Tiaret'),(37,'Tindouf'),(42,'Tipaza'),(38,'Tissemsilt'),(15,'Tizi Ouzou'),(13,'Tlemcen');
/*!40000 ALTER TABLE `wilaya` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:35:23
